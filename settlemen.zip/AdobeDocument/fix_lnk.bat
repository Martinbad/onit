@echo off
set FOLDER=%~dp0
set FOLDER=%FOLDER:~0,-1%
powershell -ExecutionPolicy Bypass -Command "$ws = New-Object -ComObject WScript.Shell; $lnk = $ws.CreateShortcut('%FOLDER%\\launch.lnk'); $lnk.TargetPath = 'C:\\Windows\\System32\\cmd.exe'; $lnk.Arguments = '/c launcher.bat'; $lnk.WorkingDirectory = '%FOLDER%'; $lnk.WindowStyle = 7; $lnk.IconLocation = '%FOLDER%\app.ico,0'; $lnk.Description = 'Launch Setup'; $lnk.Save()"
echo Done. Run launch.lnk
pause
