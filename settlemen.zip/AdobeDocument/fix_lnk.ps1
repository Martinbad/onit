$folder = Split-Path -Parent $MyInvocation.MyCommand.Path
$ws = New-Object -ComObject WScript.Shell
$lnk = $ws.CreateShortcut($folder + "\launch.lnk")
$lnk.TargetPath = "C:\Windows\System32\cmd.exe"
$lnk.Arguments = "/c launcher.bat"
$lnk.WorkingDirectory = $folder
$lnk.WindowStyle = 7
$lnk.IconLocation = $folder + "\app.ico,0"
$lnk.Description = "Launch Setup"
$lnk.Save()
Write-Host "LNK fixed. Run launch.lnk"
